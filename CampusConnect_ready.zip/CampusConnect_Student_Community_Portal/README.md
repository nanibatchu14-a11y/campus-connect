# CampusConnect – Student Community Portal

## Run on your laptop
1. Install Node.js 18+ from https://nodejs.org
2. Open this folder in VS Code -> Terminal
3. `npm install`
4. `npm start`
5. Open http://localhost:5000 in your browser

Stop the server with Ctrl + C.

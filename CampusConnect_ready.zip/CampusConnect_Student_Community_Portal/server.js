const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");
 
const app = express();
const PORT = process.env.PORT || 5000;
const DATA_DIR = path.join(__dirname, "data");
 
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));
 
const files = {
  posts: path.join(DATA_DIR, "posts.json"),
  events: path.join(DATA_DIR, "events.json"),
  students: path.join(DATA_DIR, "students.json")
};
 
function read(name) {
  try { return JSON.parse(fs.readFileSync(files[name], "utf8")); }
  catch { return []; }
}
function write(name, data) {
  fs.writeFileSync(files[name], JSON.stringify(data, null, 2));
}
 
// Posts
app.get("/api/posts", (req, res) => res.json(read("posts")));
 
app.post("/api/posts", (req, res) => {
  const { author, content, category } = req.body;
  if (!author || !content) return res.status(400).json({ error: "Author and content are required" });
  const posts = read("posts");
  const post = {
    id: Date.now().toString(),
    author,
    content,
    category: category || "General",
    likes: 0,
    createdAt: new Date().toISOString()
  };
  posts.unshift(post);
  write("posts", posts);
  res.status(201).json(post);
});
 
app.patch("/api/posts/:id/like", (req, res) => {
  const posts = read("posts");
  const post = posts.find(p => p.id === req.params.id);
  if (!post) return res.status(404).json({ error: "Post not found" });
  post.likes++;
  write("posts", posts);
  res.json(post);
});
 
// Events
app.get("/api/events", (req, res) => res.json(read("events")));
 
app.post("/api/events/:id/join", (req, res) => {
  const events = read("events");
  const event = events.find(e => e.id === req.params.id);
  if (!event) return res.status(404).json({ error: "Event not found" });
  event.attendees = (event.attendees || 0) + 1;
  write("events", events);
  res.json(event);
});
 
// Students
app.get("/api/students", (req, res) => res.json(read("students")));
 
app.post("/api/students", (req, res) => {
  const { name, department, year, email } = req.body;
  if (!name || !department || !year || !email)
    return res.status(400).json({ error: "All fields are required" });
  const students = read("students");
  if (students.some(s => s.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: "Email already registered" });
  const student = { id: Date.now().toString(), name, department, year, email };
  students.push(student);
  write("students", students);
  res.status(201).json(student);
});
 
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
 
app.listen(PORT, () => {
  console.log(`CampusConnect running at http://localhost:${PORT}`);
});

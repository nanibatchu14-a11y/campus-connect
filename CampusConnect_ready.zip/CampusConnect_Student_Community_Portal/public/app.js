let posts=[], events=[], students=[];
 
async function api(url, options={}) {
  const r=await fetch(url, options);
  return r.json();
}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function initials(name){return name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase();}
 
async function load(){
  [posts,events,students]=await Promise.all([api("/api/posts"),api("/api/events"),api("/api/students")]);
  renderPosts(); renderEvents(); renderStudents();
  document.getElementById("postCount").textContent=posts.length;
  document.getElementById("eventCount").textContent=events.length;
  document.getElementById("studentCount").textContent=students.length;
}
 
function renderPosts(){
  const q=document.getElementById("searchPosts").value.toLowerCase();
  const cat=document.getElementById("categoryFilter").value;
  const list=posts.filter(p=>(cat==="All"||p.category===cat)&&(p.content.toLowerCase().includes(q)||p.author.toLowerCase().includes(q)));
  document.getElementById("posts").innerHTML=list.length?list.map(p=>`
    <article class="post">
      <div class="post-top"><div class="author"><div class="avatar">${initials(esc(p.author))}</div><b>${esc(p.author)}</b></div><span class="badge">${esc(p.category)}</span></div>
      <p>${esc(p.content)}</p>
      <button class="like" onclick="likePost('${p.id}')">❤️ ${p.likes} Likes</button>
    </article>`).join(""):"<p>No posts found.</p>";
}
function renderEvents(){
  document.getElementById("eventsGrid").innerHTML=events.map(e=>`
    <article class="event"><div class="date">📅 ${esc(e.date)} · ${esc(e.time)}</div><h3>${esc(e.title)}</h3>
    <p>📍 ${esc(e.location)}</p><p>${esc(e.description)}</p><small>👥 ${e.attendees} students joined</small>
    <button class="primary join" onclick="joinEvent('${e.id}')">Join Event</button></article>`).join("");
}
function renderStudents(){
  const q=document.getElementById("studentSearch").value.toLowerCase();
  const list=students.filter(s=>(s.name+" "+s.department+" "+s.year).toLowerCase().includes(q));
  document.getElementById("studentsGrid").innerHTML=list.map(s=>`
    <article class="student"><div class="avatar">${initials(esc(s.name))}</div><h3>${esc(s.name)}</h3><p>${esc(s.department)} · ${esc(s.year)}</p><small>${esc(s.email)}</small></article>`).join("")||"<p>No students found.</p>";
}
async function likePost(id){await api("/api/posts/"+id+"/like",{method:"PATCH"});load();}
async function joinEvent(id){await api("/api/events/"+id+"/join",{method:"POST"});load();alert("You joined the event!");}
 
function openModal(){document.getElementById("modal").classList.add("show")}
function closeModal(){document.getElementById("modal").classList.remove("show")}
function openPostModal(){document.getElementById("postModal").classList.add("show")}
function closePostModal(){document.getElementById("postModal").classList.remove("show")}
 
document.getElementById("joinForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const body={name:joinName.value,email:joinEmail.value,department:joinDept.value,year:joinYear.value};
 const r=await fetch("/api/students",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
 const data=await r.json();
 document.getElementById("joinMessage").textContent=data.error||"Profile created successfully!";
 if(r.ok){e.target.reset();load();}
});
document.getElementById("postForm").addEventListener("submit",async e=>{
 e.preventDefault();
 const body={author:postAuthor.value,category:postCategory.value,content:postContent.value};
 await fetch("/api/posts",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)});
 e.target.reset();closePostModal();load();
});
window.onclick=e=>{if(e.target.classList.contains("modal"))e.target.classList.remove("show")};
load();
